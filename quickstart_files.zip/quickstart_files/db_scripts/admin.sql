create user quickstart identified by "QUICK11##11vue" quota unlimited on data;
grant connect, resource, pdb_dba to quickstart;