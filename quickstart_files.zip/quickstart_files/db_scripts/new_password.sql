alter user quickstart identified by "NEW_PASSWORD";
