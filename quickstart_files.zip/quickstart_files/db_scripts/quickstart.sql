@./db_scripts/admin.sql
/
@./db_scripts/rest.sql
/
@./db_scripts/auto_rest.sql
/
conn quickstart/QUICK11##11vue@QUIKDB_high

@./db_scripts/emp_create.sql

@./db_scripts/emp_popul.sql

@./db_scripts/new_password.sql

-- exit
